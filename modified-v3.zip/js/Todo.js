// A model for todos

class Todo {
  constructor(id, todoname, description, importance) {
    this._id = id;
    this._todoname = todoname;
    this._description = description;
    this._importance = importance;
  }
}
